export type PostStatus = 'Publicado' | 'Agendado' | 'Rascunho' | 'Backlog'
export type PostType = 'Carrossel' | 'Reel' | 'Story' | 'Post único' | 'Vídeo'
export type PostImage = 'none' | 'freepik' | 'ai'
export type ContentTone = 'profissional' | 'informal' | 'divertido' | 'educativo' | 'inspirador'
export type ContentType = 'carrossel' | 'post' | 'story' | 'reel' | 'thread' | 'video'
export type TextModel = 'claude-sonnet-4-5' | 'claude-opus-4-5' | 'gemini-1.5-flash' | 'gemini-1.5-pro'
export type ImageModel = 'fal-flux' | 'fal-sdxl' | 'fal-flux-pro'
export type VideoModel = 'seedance-v1' | 'seedance-v1-lite' | 'higgsfield-seedance'

export interface Post {
  id: string
  title: string
  caption: string
  type: PostType
  status: PostStatus
  date: string
  img: PostImage
  profileId?: string
  created_at?: string
}

export interface Competitor {
  id: string; handle: string; seg: string; eng: string
  freq: number; trend: string; nicho: string; cor: string; created_at?: string
}

export interface Slide {
  id: string; heading: string; body: string; imagePrompt?: string; imageUrl?: string
}

export interface GeneratedContent {
  id: string; type: ContentType; title: string; topic: string; tone: ContentTone
  platform: string; slides?: Slide[]; body?: string; hashtags?: string[]
  videoUrl?: string; textModel: TextModel; imageModel?: ImageModel; videoModel?: VideoModel
  templateId?: string; profileId?: string; createdAt: string
  status: 'draft' | 'approved' | 'scheduled' | 'published'
}

export interface Profile {
  id: string
  name: string
  handle: string
  description: string
  niche: string
  audience: string
  tone: ContentTone
  keywords: string[]
  brandColors: string[]
  fontDisplay: string
  fontBody: string
  socialNetworks: string[]
  competitors: string[]
  avatar?: string
  isDefault: boolean
  createdAt: string
}

export interface BrandTemplate {
  id: string; name: string; thumbnail: string; originalUrl?: string
  colors: string[]; primaryColor: string; secondaryColor: string
  accentColor: string; darkColor: string; lightColor: string
  fontDisplay: string; fontBody: string
  style: 'editorial' | 'bold' | 'minimal' | 'warm' | 'tech' | 'medical'
  tone: ContentTone; notes: string; profileId?: string; createdAt: string
}

export interface BusinessProfile {
  name: string; description: string; niche: string; audience: string
  tone: ContentTone; keywords: string[]; brandColors: string[]
  socialNetworks: string[]; competitors: string[]; instagramHandle: string
}

export interface ApiKeys {
  anthropic?: string; gemini?: string; openai?: string; freepik?: string
  falai?: string; perplexity?: string; higgsfield?: string
  supabaseUrl?: string; supabaseKey?: string
}

export interface AppConfig {
  apiKeys: ApiKeys; textModel: TextModel; imageModel: ImageModel
  videoModel: VideoModel; theme: 'dark' | 'light'; activeProfileId: string
}

export interface ScheduledDay {
  date: string; contentId?: string; contentType?: ContentType
  topic?: string; status: 'empty' | 'planned' | 'published'; profileId?: string
}

export interface VideoGeneration {
  id: string
  prompt: string
  model: VideoModel
  duration: number
  aspectRatio: string
  jobId?: string
  status: 'pending' | 'processing' | 'done' | 'error'
  videoUrl?: string
  imageUrl?: string
  error?: string
  profileId?: string
  createdAt: string
}

export interface VideoGeneration {
  id: string
  prompt: string
  model: VideoModel
  duration: number
  aspectRatio: string
  status: 'pending' | 'processing' | 'done' | 'error'
  jobId?: string
  videoUrl?: string
  imageUrl?: string
  error?: string
  profileId?: string
  createdAt: string
}
