import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { prompt, model, duration, aspectRatio, apiKeys } = await req.json()
    const key = (apiKeys?.higgsfield as string) || process.env.HIGGSFIELD_API_KEY
    if (!key) return NextResponse.json({ error: 'Chave Higgs Field nao configurada. Va em APIs.' }, { status: 400 })

    const modelId = model === 'seedance-v1-lite' ? 'seedance-v1-lite' : 'seedance-v1'

    const submitRes = await fetch('https://api.higgsfield.ai/v1/video/generate', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, prompt, duration: duration || 5, aspect_ratio: aspectRatio || '9:16' }),
    })

    if (!submitRes.ok) {
      const err = await submitRes.text()
      return NextResponse.json({ error: `Higgs Field ${submitRes.status}: ${err}` }, { status: submitRes.status })
    }

    const submitData = await submitRes.json()
    const jobId = submitData.id || submitData.job_id

    if (!jobId) return NextResponse.json({ error: 'Job ID nao retornado' }, { status: 500 })

    // Poll up to 5 attempts (10s), then return jobId for client polling
    for (let i = 0; i < 5; i++) {
      await new Promise(r => setTimeout(r, 2000))
      const pollRes = await fetch(`https://api.higgsfield.ai/v1/video/${jobId}`, {
        headers: { 'Authorization': `Bearer ${key}` },
      })
      if (!pollRes.ok) continue
      const pollData = await pollRes.json()
      if (pollData.status === 'completed' || pollData.status === 'succeeded') {
        const url = pollData.video_url || pollData.output?.video_url || ''
        return NextResponse.json({ url, jobId, status: 'done' })
      }
      if (pollData.status === 'failed') {
        return NextResponse.json({ error: 'Geracao falhou: ' + (pollData.error || 'desconhecido') }, { status: 500 })
      }
    }

    // Still processing — client should poll /api/video/status
    return NextResponse.json({ jobId, status: 'processing', message: 'Video em geracao. Verifique o status.' }, { status: 202 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro ao gerar video' }, { status: 500 })
  }
}
