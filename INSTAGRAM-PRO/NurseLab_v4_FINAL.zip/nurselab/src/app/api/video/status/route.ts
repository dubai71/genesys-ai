import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { jobId, apiKeys } = await req.json()
    const key = (apiKeys?.higgsfield as string) || process.env.HIGGSFIELD_API_KEY
    if (!key || !jobId) return NextResponse.json({ error: 'Parametros invalidos' }, { status: 400 })
    const res = await fetch(`https://api.higgsfield.ai/v1/video/${jobId}`, {
      headers: { 'Authorization': `Bearer ${key}` },
    })
    const data = await res.json()
    if (data.status === 'completed' || data.status === 'succeeded') {
      return NextResponse.json({ status: 'done', url: data.video_url || data.output?.video_url || '' })
    }
    return NextResponse.json({ status: data.status || 'processing' })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
