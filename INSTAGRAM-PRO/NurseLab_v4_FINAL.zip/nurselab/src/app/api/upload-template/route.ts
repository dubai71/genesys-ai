import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File | null
    const keysRaw = formData.get('apiKeys') as string | null
    const apiKeys = keysRaw ? JSON.parse(keysRaw) : {}

    const supabaseUrl = (apiKeys.supabaseUrl as string) || process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = (apiKeys.supabaseKey as string) || process.env.NEXT_PUBLIC_SUPABASE_KEY

    if (!supabaseUrl || !supabaseKey) {
      return NextResponse.json({ error: 'Supabase nao configurado.' }, { status: 400 })
    }
    if (!file) return NextResponse.json({ error: 'Nenhum arquivo enviado.' }, { status: 400 })

    const filename = `templates/${Date.now()}-${file.name.replace(/\s+/g, '-')}`
    const buffer = await file.arrayBuffer()

    const res = await fetch(`${supabaseUrl}/storage/v1/object/nurselab/${filename}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': file.type || 'image/jpeg',
        'x-upsert': 'true',
      },
      body: buffer,
    })

    if (!res.ok) {
      const err = await res.text()
      return NextResponse.json({ error: `Supabase Storage erro: ${err}` }, { status: res.status })
    }

    const publicUrl = `${supabaseUrl}/storage/v1/object/public/nurselab/${filename}`
    return NextResponse.json({ url: publicUrl })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro no upload' }, { status: 500 })
  }
}
