'use client'
import { useState, useRef } from 'react'
import { storage } from '@/lib/storage'
import { generateContent, generateImage, generateHashtags } from '@/lib/ai'
import type { ContentType, ContentTone, TextModel, ImageModel, GeneratedContent } from '@/types'
import Button from '../ui/Button'
import Input from '../ui/Input'
import Select from '../ui/Select'
import PageHeader from '../ui/PageHeader'
import Badge from '../ui/Badge'

const TEXT_MODELS = [
  { value: 'claude-sonnet-4-5', label: '✦ Claude Sonnet 4.5 (recomendado)' },
  { value: 'claude-opus-4-5', label: '✦ Claude Opus 4.5 (mais poderoso)' },
  { value: 'gemini-1.5-flash', label: '◆ Gemini 1.5 Flash (rápido)' },
  { value: 'gemini-1.5-pro', label: '◆ Gemini 1.5 Pro' },
]
const IMAGE_MODELS = [
  { value: 'fal-flux', label: '⚡ Flux Schnell — fal.ai (rápido)' },
  { value: 'fal-sdxl', label: '🎨 SDXL — fal.ai (qualidade)' },
  { value: 'fal-flux-pro', label: '✦ Flux Pro — fal.ai (premium)' },
]
const TYPES = [
  { value: 'carrossel', icon: '🎠', label: 'Carrossel Instagram' },
  { value: 'post', icon: '🖼', label: 'Post único' },
  { value: 'story', icon: '📱', label: 'Story / Ideia' },
  { value: 'reel', icon: '🎬', label: 'Reel / TikTok' },
  { value: 'thread', icon: '🧵', label: 'Thread Twitter/X' },
]
const TONES = [
  { value: 'profissional', label: 'Profissional' },
  { value: 'educativo', label: 'Educativo' },
  { value: 'inspirador', label: 'Inspirador' },
  { value: 'informal', label: 'Informal' },
  { value: 'divertido', label: 'Divertido' },
]

const TEMPLATES = [
  { label: 'Dicas numeradas', topic: 'X dicas para enfermeiros usarem IA no plantão' },
  { label: 'Mitos vs Realidade', topic: 'Mitos e realidades sobre IA na enfermagem' },
  { label: 'Passo a passo', topic: 'Como usar Claude para estudar para residência' },
  { label: 'Antes / Depois', topic: 'Antes e depois de usar IA na rotina de enfermagem' },
  { label: 'Erros comuns', topic: 'Erros que enfermeiros cometem ao tentar crescer digitalmente' },
]

type LoadingStep = { msg: string; done: boolean }

export default function Conteudo() {
  const [type, setType] = useState<ContentType>('carrossel')
  const [topic, setTopic] = useState('')
  const [tone, setTone] = useState<ContentTone>('profissional')
  const [textModel, setTextModel] = useState<TextModel>('claude-sonnet-4-5')
  const [imageModel, setImageModel] = useState<ImageModel>('fal-flux')
  const [slidesCount, setSlidesCount] = useState(7)
  const [genImages, setGenImages] = useState(false)
  const [genHashtags, setGenHashtags] = useState(true)
  const [loading, setLoading] = useState(false)
  const [steps, setSteps] = useState<LoadingStep[]>([])
  const [result, setResult] = useState<GeneratedContent | null>(null)
  const [editSlide, setEditSlide] = useState<number | null>(null)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)
  const abortRef = useRef(false)

  function addStep(msg: string) {
    setSteps(prev => [...prev, { msg, done: false }])
  }
  function doneStep() {
    setSteps(prev => prev.map((s, i) => i === prev.length - 1 ? { ...s, done: true } : s))
  }

  async function handleGenerate() {
    if (!topic.trim()) { setError('Digite o tema do conteúdo'); return }
    setError(''); setResult(null); setSteps([]); setLoading(true); abortRef.current = false

    try {
      const cfg = storage.getConfig()
      const biz = storage.getBusiness()
      const keys = cfg.apiKeys as Record<string, string>

      // Step 1: generate text
      addStep(`Gerando ${type} com ${textModel}…`)
      const data = await generateContent({ type, topic, tone, textModel, business: biz, apiKeys: keys, slidesCount })
      doneStep()

      let slides = data.slides || []
      let hashtags = data.hashtags || []
      let body = data.body || ''

      // Step 2: generate images per slide
      if (genImages && slides.length > 0) {
        for (let i = 0; i < slides.length; i++) {
          if (abortRef.current) break
          addStep(`Gerando imagem ${i + 1}/${slides.length}…`)
          try {
            const url = await generateImage({
              prompt: slides[i].imagePrompt || `${topic}, enfermagem, ambiente clínico profissional`,
              imageModel,
              apiKeys: keys,
            })
            slides[i] = { ...slides[i], imageUrl: url }
          } catch (imgErr: any) {
            // non-fatal: slide without image
          }
          doneStep()
        }
      }

      // Step 3: hashtags
      if (genHashtags) {
        addStep('Gerando hashtags inteligentes…')
        try {
          const tags = await generateHashtags({ content: topic, niche: biz.niche, apiKeys: keys })
          hashtags = [...(tags.high || []), ...(tags.medium || []), ...(tags.niche || [])]
        } catch {}
        doneStep()
      }

      const content: GeneratedContent = {
        id: Date.now().toString(),
        type, title: topic, topic, tone,
        platform: 'instagram',
        slides: slides.length > 0 ? slides : undefined,
        body: body || undefined,
        hashtags,
        textModel,
        imageModel: genImages ? imageModel : undefined,
        createdAt: new Date().toISOString(),
        status: 'draft',
      }

      storage.addContent(content)
      setResult(content)
    } catch (e: any) {
      setError(e.message || 'Erro inesperado. Verifique suas API keys em Configurações.')
    }

    setLoading(false)
  }

  function copyAll() {
    if (!result) return
    let text = ''
    if (result.slides) {
      text = result.slides.map((s, i) => `=== Slide ${i + 1} ===\n${s.heading}\n${s.body}`).join('\n\n')
    } else {
      text = result.body || ''
    }
    if (result.hashtags?.length) text += '\n\n' + result.hashtags.join(' ')
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function saveAsDraft() {
    if (!result) return
    storage.addPost({
      id: Date.now().toString(),
      title: result.title,
      caption: result.slides?.[0]?.body || result.body || '',
      type: type === 'carrossel' ? 'Carrossel' : type === 'reel' ? 'Reel' : type === 'story' ? 'Story' : 'Post único',
      status: 'Rascunho', date: '', img: 'none',
    })
    alert('✓ Salvo como rascunho no Instagram!')
  }

  function updateSlide(idx: number, field: 'heading' | 'body', val: string) {
    if (!result?.slides) return
    const slides = [...result.slides]
    slides[idx] = { ...slides[idx], [field]: val }
    setResult({ ...result, slides })
    // persist updated content
    const all = storage.getContent()
    const updated = all.map(c => c.id === result.id ? { ...result, slides } : c)
    storage.setContent(updated)
  }

  return (
    <div className="flex h-full overflow-hidden">
      {/* LEFT: config */}
      <div className="w-72 flex-shrink-0 border-r border-white/[0.08] flex flex-col overflow-y-auto bg-[#050505]">
        <div className="p-4 border-b border-white/[0.08]">
          <h1 className="font-display text-lg font-bold text-white">Criar Conteúdo</h1>
          <p className="text-[10px] text-[rgba(237,218,186,0.4)] mt-0.5">Gere com IA, edite, publique</p>
        </div>

        <div className="p-4 flex flex-col gap-3 flex-1 overflow-y-auto">
          {/* Templates rápidos */}
          <div>
            <div className="text-[8px] font-bold tracking-[1.5px] uppercase text-[rgba(237,218,186,0.22)] mb-1.5">Templates rápidos</div>
            <div className="flex flex-col gap-1">
              {TEMPLATES.map(t => (
                <button key={t.label} onClick={() => setTopic(t.topic)}
                  className="text-left px-2.5 py-1.5 rounded-[5px] text-[10px] text-[rgba(237,218,186,0.5)] hover:text-[#FF5404] hover:bg-[rgba(255,84,4,0.08)] transition-all border border-transparent hover:border-[rgba(255,84,4,0.15)]">
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Type */}
          <div>
            <div className="text-[8px] font-bold tracking-[1.5px] uppercase text-[rgba(237,218,186,0.22)] mb-1.5">Tipo</div>
            <div className="flex flex-col gap-1">
              {TYPES.map(t => (
                <button key={t.value} onClick={() => setType(t.value as ContentType)}
                  className={`flex items-center gap-2 px-2.5 py-2 rounded-[6px] text-[11px] text-left transition-all border
                    ${type === t.value
                      ? 'bg-[rgba(255,84,4,0.13)] text-[#FF5404] border-[rgba(255,84,4,0.3)]'
                      : 'text-[rgba(237,218,186,0.45)] border-white/[0.06] hover:border-white/20'}`}>
                  <span>{t.icon}</span><span>{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Topic */}
          <Input label="Tema / Assunto" value={topic}
            onChange={e => setTopic(e.target.value)}
            placeholder="Ex: IA na triagem de enfermagem" />

          {/* Tone */}
          <Select label="Tom de voz" value={tone}
            onChange={e => setTone(e.target.value as ContentTone)}
            options={TONES} />

          {/* Slides count */}
          {type === 'carrossel' && (
            <Select label="Slides" value={String(slidesCount)}
              onChange={e => setSlidesCount(Number(e.target.value))}
              options={[5, 7, 8, 10].map(n => ({ value: String(n), label: `${n} slides` }))} />
          )}

          {/* Models */}
          <Select label="Modelo de texto" value={textModel}
            onChange={e => setTextModel(e.target.value as TextModel)}
            options={TEXT_MODELS} />

          <div className="flex flex-col gap-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={genImages} onChange={e => setGenImages(e.target.checked)} className="accent-[#FF5404]" />
              <span className="text-[11px] text-[rgba(237,218,186,0.6)]">Gerar imagens com IA</span>
            </label>
            {genImages && (
              <Select label="Modelo de imagem" value={imageModel}
                onChange={e => setImageModel(e.target.value as ImageModel)}
                options={IMAGE_MODELS} />
            )}
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={genHashtags} onChange={e => setGenHashtags(e.target.checked)} className="accent-[#FF5404]" />
              <span className="text-[11px] text-[rgba(237,218,186,0.6)]">Gerar hashtags (30 tags)</span>
            </label>
          </div>

          {error && (
            <div className="text-[10px] text-[#ef4444] bg-[rgba(239,68,68,0.08)] border border-[rgba(239,68,68,0.2)] rounded-[6px] px-3 py-2 leading-relaxed">
              ⚠ {error}
            </div>
          )}

          <Button onClick={handleGenerate} disabled={loading} className="w-full mt-1">
            {loading ? '⏳ Gerando…' : '✨ Gerar Conteúdo'}
          </Button>

          {loading && (
            <button onClick={() => { abortRef.current = true; setLoading(false) }}
              className="text-[10px] text-[rgba(237,218,186,0.4)] hover:text-[#ef4444] text-center">
              Cancelar
            </button>
          )}
        </div>
      </div>

      {/* RIGHT: preview */}
      <div className="flex-1 overflow-y-auto p-5">
        {/* Loading steps */}
        {loading && (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <div className="w-8 h-8 border-2 border-white/10 border-t-[#FF5404] rounded-full animate-spin" />
            <div className="flex flex-col gap-2 min-w-[260px]">
              {steps.map((s, i) => (
                <div key={i} className={`flex items-center gap-2 text-[11px] transition-colors ${s.done ? 'text-[#22c55e]' : 'text-[#FF5404]'}`}>
                  <span>{s.done ? '✓' : '⏳'}</span>
                  <span>{s.msg}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty state */}
        {!loading && !result && (
          <div className="flex flex-col items-center justify-center h-full text-center gap-3">
            <div className="text-5xl opacity-10">✨</div>
            <div className="font-display text-xl text-white opacity-25">Configure e gere</div>
            <div className="text-[11px] text-[rgba(237,218,186,0.2)]">O conteúdo aparecerá aqui com preview interativo</div>
          </div>
        )}

        {/* Result */}
        {result && !loading && (
          <div className="flex flex-col gap-5">
            {/* Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display text-lg font-bold text-white">{result.title}</h2>
                <div className="flex gap-1.5 mt-1 flex-wrap">
                  <Badge variant="brand">{result.type}</Badge>
                  <Badge variant="muted">{result.tone}</Badge>
                  <Badge variant="muted">{result.textModel}</Badge>
                  {result.imageModel && <Badge variant="amber">{result.imageModel}</Badge>}
                </div>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button variant="ghost" size="sm" onClick={copyAll}>
                  {copied ? '✓ Copiado!' : '📋 Copiar tudo'}
                </Button>
                <Button variant="ghost" size="sm" onClick={saveAsDraft}>💾 Rascunho</Button>
                <Button size="sm" onClick={() => { setResult(null); setSteps([]) }}>+ Novo</Button>
              </div>
            </div>

            {/* Slides preview */}
            {result.slides && (
              <>
                <div className="text-[9px] font-bold tracking-[2px] uppercase text-[rgba(237,218,186,0.2)]">
                  {result.slides.length} slides · clique para editar
                </div>
                <div className="grid grid-cols-4 gap-3">
                  {result.slides.map((slide, idx) => (
                    <div key={slide.id || idx}>
                      {/* Instagram 4:5 card */}
                      <div className="relative rounded-[8px] overflow-hidden cursor-pointer"
                        style={{ aspectRatio: '4/5', background: 'linear-gradient(165deg, #071925 0%, #0d2438 100%)' }}
                        onClick={() => setEditSlide(editSlide === idx ? null : idx)}>
                        {/* Background image */}
                        {slide.imageUrl && (
                          <img src={slide.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover opacity-50" />
                        )}
                        {/* Gradient overlay */}
                        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.92) 0%, transparent 55%)' }} />
                        {/* Loading image placeholder */}
                        {genImages && !slide.imageUrl && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="text-[rgba(237,218,186,0.15)] text-xs">sem imagem</div>
                          </div>
                        )}
                        {/* Content */}
                        <div className="absolute inset-0 flex flex-col justify-end p-3">
                          {editSlide === idx ? (
                            <div className="flex flex-col gap-1.5" onClick={e => e.stopPropagation()}>
                              <textarea value={slide.heading} rows={2}
                                className="bg-black/60 border border-white/20 rounded px-2 py-1 text-[10px] text-white w-full resize-none"
                                onChange={e => updateSlide(idx, 'heading', e.target.value)} />
                              <textarea value={slide.body} rows={3}
                                className="bg-black/60 border border-white/20 rounded px-2 py-1 text-[9px] text-white/70 w-full resize-none"
                                onChange={e => updateSlide(idx, 'body', e.target.value)} />
                              <button onClick={() => setEditSlide(null)}
                                className="text-[9px] text-[#FF5404] hover:underline">✓ Salvar edição</button>
                            </div>
                          ) : (
                            <>
                              <div className="text-[10px] font-bold text-white leading-tight mb-1">{slide.heading}</div>
                              <div className="text-[8px] text-white/65 leading-snug line-clamp-3">{slide.body}</div>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-[7px] text-white/30">{idx + 1}/{result.slides!.length}</span>
                                <span className="text-[7px] text-[#FF5404]">✏ editar</span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                      {/* Image prompt below card */}
                      {slide.imagePrompt && (
                        <div className="mt-1 text-[8px] text-[rgba(237,218,186,0.25)] leading-tight px-0.5 line-clamp-2">
                          🎨 {slide.imagePrompt}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* Thread / Post body */}
            {result.body && !result.slides && (
              <div className="bg-[#0a0a0a] border border-white/[0.08] rounded-[9px] p-4">
                <div className="text-[9px] font-bold tracking-[1.5px] uppercase text-[rgba(237,218,186,0.22)] mb-3">Conteúdo gerado</div>
                {result.type === 'thread' ? (
                  <div className="flex flex-col gap-3">
                    {result.body.split('---').map((tweet, i) => (
                      <div key={i} className="flex gap-3">
                        <div className="w-5 h-5 rounded-full bg-[rgba(255,84,4,0.2)] flex items-center justify-center text-[8px] text-[#FF5404] font-bold flex-shrink-0 mt-0.5">{i + 1}</div>
                        <pre className="text-[11px] text-[rgba(237,218,186,0.75)] whitespace-pre-wrap leading-relaxed font-body flex-1">{tweet.trim()}</pre>
                      </div>
                    ))}
                  </div>
                ) : (
                  <pre className="text-[11px] text-[rgba(237,218,186,0.75)] whitespace-pre-wrap leading-relaxed font-body">{result.body}</pre>
                )}
              </div>
            )}

            {/* Hashtags */}
            {result.hashtags && result.hashtags.length > 0 && (
              <div className="bg-[#0a0a0a] border border-white/[0.08] rounded-[9px] p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[9px] font-bold tracking-[1.5px] uppercase text-[rgba(237,218,186,0.22)]">
                    Hashtags · {result.hashtags.length} tags
                  </div>
                  <button onClick={() => navigator.clipboard.writeText(result.hashtags!.join(' '))}
                    className="text-[9px] text-[rgba(237,218,186,0.35)] hover:text-[#FF5404]">
                    📋 copiar
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {result.hashtags.map(h => (
                    <span key={h} className="px-2 py-0.5 bg-[rgba(255,84,4,0.08)] text-[#FF5404] rounded text-[9px] font-medium cursor-pointer hover:bg-[rgba(255,84,4,0.15)]"
                      onClick={() => navigator.clipboard.writeText(h)}>
                      {h}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
