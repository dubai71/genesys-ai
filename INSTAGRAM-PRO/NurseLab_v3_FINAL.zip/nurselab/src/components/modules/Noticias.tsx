'use client'
import { useState, useEffect } from 'react'
import { storage } from '@/lib/storage'
import { fetchNews } from '@/lib/ai'
import PageHeader from '../ui/PageHeader'
import Badge from '../ui/Badge'

type Category = 'todos' | 'ia' | 'enfermagem' | 'negocios' | 'ferramentas'

const CAT_LABEL: Record<string, string> = { ia:'IA', enfermagem:'Enfermagem', negocios:'Negócios', ferramentas:'Ferramentas' }
const CAT_BADGE: Record<string, 'brand'|'green'|'blue'|'purple'> = { ia:'brand', enfermagem:'purple', negocios:'green', ferramentas:'blue' }

const FALLBACK = [
  { id:'n1', title:'IA generativa transforma protocolos de triagem em UTIs', summary:'Redução de 31% no tempo de triagem com modelos de linguagem integrados a sistemas hospitalares brasileiros.', source:'MIT Technology Review', url:'#', date:'Há 2h', category:'ia' },
  { id:'n2', title:'COFEN discute regulamentação do uso de IA na enfermagem', summary:'Grupo de trabalho analisa diretrizes para uso responsável de IA em decisões clínicas de enfermagem.', source:'COFEN Notícias', url:'#', date:'Há 5h', category:'enfermagem' },
  { id:'n3', title:'Enfermeiros faturam R$40K/mês com infoprodutos digitais', summary:'Crescimento de 180% na venda de cursos e mentorias por enfermeiros em 2025.', source:'Hotmart Blog', url:'#', date:'Há 8h', category:'negocios' },
  { id:'n4', title:'Flux Pro 1.1: nova versão gera imagens médicas fotorrealistas', summary:'Modelo especializado para contextos clínicos com suporte a material educativo de saúde.', source:'fal.ai Blog', url:'#', date:'Há 12h', category:'ferramentas' },
  { id:'n5', title:'Mercado para enfermeiros com competências digitais cresce 28%', summary:'Relatório aponta forte demanda por enfermeiros com habilidades digitais e gestão até 2030.', source:'COFEN', url:'#', date:'Ontem', category:'enfermagem' },
  { id:'n6', title:'Claude para saúde: documentação clínica com IA', summary:'Times de enfermagem usam Claude para padronizar evoluções e reduzir carga administrativa em 40%.', source:'Anthropic Blog', url:'#', date:'Ontem', category:'ia' },
  { id:'n7', title:'NurseTools lança versão gratuita para profissionais autônomos', summary:'500 automações/mês gratuitas para profissionais de saúde independentes.', source:'Product Hunt', url:'#', date:'2 dias', category:'ferramentas' },
  { id:'n8', title:'Micro-SaaS para saúde: oportunidade de R$2B até 2027', summary:'Software para profissionais de saúde autônomos cresce 4x mais que o mercado geral.', source:'Sebrae', url:'#', date:'3 dias', category:'negocios' },
]

export default function Noticias() {
  const [news, setNews] = useState(FALLBACK)
  const [filter, setFilter] = useState<Category>('todos')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [lastFetch, setLastFetch] = useState<string | null>(null)
  const [hasKey, setHasKey] = useState(false)
  const [usingFallback, setUsingFallback] = useState(true)

  useEffect(() => {
    const cfg = storage.getConfig()
    const hasPerplexity = !!cfg.apiKeys.perplexity
    setHasKey(hasPerplexity)
    // Auto-fetch if key exists
    if (hasPerplexity) handleFetch('todos', cfg.apiKeys as Record<string, string>)
  }, [])

  async function handleFetch(cat: Category, keysOverride?: Record<string, string>) {
    const cfg = storage.getConfig()
    const keys = keysOverride || cfg.apiKeys as Record<string, string>

    if (!keys.perplexity) {
      setError('Cole sua chave Perplexity em APIs & Configurações para ativar notícias em tempo real.')
      return
    }

    setLoading(true); setError('')
    try {
      const items = await fetchNews({ category: cat, apiKeys: keys })
      if (items.length > 0) {
        setNews(items)
        setUsingFallback(false)
        setLastFetch(new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }))
      }
    } catch (e: any) {
      setError(e.message || 'Erro ao buscar notícias. Exibindo dados locais.')
      setNews(FALLBACK)
      setUsingFallback(true)
    }
    setLoading(false)
  }

  function changeFilter(f: Category) {
    setFilter(f)
    if (hasKey) handleFetch(f)
  }

  const filtered = filter === 'todos' ? news : news.filter(n => n.category === filter)

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Notícias"
        subtitle="IA · Enfermagem · Saúde Digital · Negócios"
        actions={[{
          label: loading ? '⏳ Buscando…' : '🔄 Atualizar',
          onClick: () => handleFetch(filter),
          variant: 'primary',
        }]}
      />

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {/* Status banner */}
        {!hasKey && (
          <div className="flex items-start gap-2 bg-[rgba(245,158,11,0.08)] border border-[rgba(245,158,11,0.2)] rounded-[7px] px-3 py-2.5">
            <span className="text-sm flex-shrink-0">⚠️</span>
            <div className="text-[10px] text-[rgba(237,218,186,0.6)] leading-relaxed">
              <strong className="text-[#f59e0b]">Perplexity AI não configurado.</strong>{' '}
              Acesse <strong>APIs & Configurações</strong> → cole sua chave <code className="text-[#FF5404]">pplx-...</code> para ativar notícias em tempo real com busca na web.
            </div>
          </div>
        )}

        {hasKey && !usingFallback && lastFetch && (
          <div className="flex items-center gap-2 text-[9px] text-[rgba(237,218,186,0.3)]">
            <div className="w-1.5 h-1.5 rounded-full bg-[#3ecf8e]" />
            Perplexity AI · última busca: {lastFetch}
          </div>
        )}

        {error && (
          <div className="text-[10px] text-[#ef4444] bg-[rgba(239,68,68,0.08)] border border-[rgba(239,68,68,0.2)] rounded-[6px] px-3 py-2">
            {error}
          </div>
        )}

        {usingFallback && hasKey && !loading && (
          <div className="text-[9px] text-[rgba(237,218,186,0.25)] italic">Exibindo notícias de exemplo · Clique em Atualizar para buscar notícias reais</div>
        )}

        {/* Filters */}
        <div className="flex gap-1.5 flex-wrap">
          {(['todos', 'ia', 'enfermagem', 'negocios', 'ferramentas'] as Category[]).map(f => (
            <button key={f} onClick={() => changeFilter(f)}
              className={`px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all
                ${filter === f ? 'bg-[rgba(255,84,4,0.13)] border-[#FF5404] text-[#FF5404]'
                  : 'border-white/[0.08] text-[rgba(237,218,186,0.45)] hover:border-white/20'}`}>
              {f === 'todos' ? 'Todos' : CAT_LABEL[f]}
            </button>
          ))}
        </div>

        {/* News */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <div className="w-7 h-7 border-2 border-white/10 border-t-[#FF5404] rounded-full animate-spin" />
            <div className="text-[11px] text-[rgba(237,218,186,0.4)]">Buscando com Perplexity AI…</div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {filtered.map(n => (
              <a key={n.id}
                href={n.url !== '#' ? n.url : undefined}
                target={n.url !== '#' ? '_blank' : undefined}
                rel="noreferrer"
                className="block bg-[#0a0a0a] border border-white/[0.08] rounded-[9px] p-4 hover:border-[rgba(255,84,4,0.22)] transition-colors group cursor-pointer">
                <div className="text-[8px] font-bold tracking-[1px] uppercase text-[#FF5404] mb-1.5">{n.source}</div>
                <div className="text-[12px] font-semibold text-white mb-1.5 leading-snug group-hover:text-[#FF5404] transition-colors">{n.title}</div>
                <div className="text-[10px] text-[rgba(237,218,186,0.5)] leading-relaxed mb-2.5">{n.summary}</div>
                <div className="flex items-center gap-2">
                  <Badge variant={CAT_BADGE[n.category] || 'muted'}>{CAT_LABEL[n.category] || n.category}</Badge>
                  <span className="text-[9px] text-[rgba(237,218,186,0.25)] ml-auto">{n.date}</span>
                  {n.url !== '#' && <span className="text-[9px] text-[rgba(237,218,186,0.3)] group-hover:text-[#FF5404]">↗</span>}
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
