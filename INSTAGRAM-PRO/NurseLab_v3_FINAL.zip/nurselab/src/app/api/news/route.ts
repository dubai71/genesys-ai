import { NextRequest, NextResponse } from 'next/server'

const QUERIES: Record<string, string> = {
  todos: 'enfermagem inteligência artificial saúde digital Brasil 2026',
  ia: 'inteligência artificial enfermagem saúde clínica IA 2026',
  enfermagem: 'enfermagem Brasil COFEN regulamentação notícias recentes',
  negocios: 'empreendedorismo saúde infoproduto monetização enfermeiro renda',
  ferramentas: 'ferramentas IA saúde tecnologia hospitalar SaaS enfermagem',
}

export async function POST(req: NextRequest) {
  try {
    const { category, apiKeys } = await req.json()
    const key = apiKeys?.perplexity || process.env.PERPLEXITY_API_KEY

    if (!key) {
      return NextResponse.json(
        { error: 'Chave Perplexity não configurada.' },
        { status: 400 }
      )
    }

    const query = QUERIES[category] || QUERIES.todos

    const res = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.1-sonar-large-128k-online',
        messages: [
          {
            role: 'system',
            content: `Você é um agregador de notícias especializado em enfermagem, saúde e IA no Brasil.
Retorne APENAS JSON válido, sem markdown, sem texto antes ou depois.
Formato obrigatório:
{"news":[{"title":"string","summary":"string max 180 chars","source":"string","url":"string","category":"ia|enfermagem|negocios|ferramentas","date":"string ex: Há 2h"}]}`,
          },
          {
            role: 'user',
            content: `Busque as 8 notícias mais recentes e relevantes sobre: ${query}.
Foque em conteúdo publicado nas últimas 72 horas.
Categorize cada uma: ia, enfermagem, negocios, ou ferramentas.
Retorne APENAS o JSON, sem nenhum texto adicional.`,
          },
        ],
        max_tokens: 2000,
        temperature: 0.1,
        return_citations: true,
        search_recency_filter: 'week',
      }),
    })

    if (!res.ok) {
      const err = await res.text()
      return NextResponse.json(
        { error: `Perplexity erro ${res.status}: ${err}` },
        { status: res.status }
      )
    }

    const data = await res.json()
    const text = data.choices?.[0]?.message?.content || ''
    const clean = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim()

    try {
      const parsed = JSON.parse(clean)
      // Validate categories
      const validCats = ['ia', 'enfermagem', 'negocios', 'ferramentas']
      const news = (parsed.news || []).map((n: any, i: number) => ({
        id: `p-${Date.now()}-${i}`,
        title: n.title || '',
        summary: n.summary || '',
        source: n.source || 'Perplexity',
        url: n.url || '#',
        date: n.date || 'Recente',
        category: validCats.includes(n.category) ? n.category : 'ia',
      }))
      return NextResponse.json({ news })
    } catch {
      const match = clean.match(/\{[\s\S]*\}/)
      if (match) {
        try {
          return NextResponse.json(JSON.parse(match[0]))
        } catch {}
      }
      return NextResponse.json(
        { error: 'Erro ao processar resposta do Perplexity' },
        { status: 500 }
      )
    }
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro interno' }, { status: 500 })
  }
}
