import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { prompt, model, apiKeys } = await req.json()
    const key = apiKeys?.falai || process.env.FAL_API_KEY

    if (!key) {
      return NextResponse.json(
        { error: 'Chave fal.ai não configurada. Vá em APIs & Configurações.' },
        { status: 400 }
      )
    }

    // Correct fal.ai model IDs
    const modelMap: Record<string, string> = {
      'fal-flux': 'fal-ai/flux/schnell',
      'fal-sdxl': 'fal-ai/stable-diffusion-xl',
      'fal-flux-pro': 'fal-ai/flux-pro',
    }
    const modelId = modelMap[model] || 'fal-ai/flux/schnell'

    // fal.ai REST API (not fal.run - that's the old SDK method)
    const res = await fetch(`https://fal.run/${modelId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Key ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: prompt + ', professional photography, medical healthcare setting, dark blue background #071925, orange accent #FF5404, cinematic lighting, 4k',
        image_size: 'portrait_4_3',
        num_inference_steps: 4,
        num_images: 1,
        enable_safety_checker: true,
      }),
    })

    if (!res.ok) {
      const err = await res.text()
      return NextResponse.json(
        { error: `fal.ai erro ${res.status}: ${err}` },
        { status: res.status }
      )
    }

    const data = await res.json()
    const imageUrl = data.images?.[0]?.url || data.image?.url || ''

    if (!imageUrl) {
      return NextResponse.json({ error: 'fal.ai não retornou imagem' }, { status: 500 })
    }

    return NextResponse.json({ url: imageUrl })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro ao gerar imagem' }, { status: 500 })
  }
}
